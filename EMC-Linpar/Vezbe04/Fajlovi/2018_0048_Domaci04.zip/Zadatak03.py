from cProfile import label
import numpy as np
import matplotlib.pyplot as plt
import math

print('w1= 1.75mm, a1= 3.101E+00 dB/m, A1=',
      str(3.101*0.24), 'dB, w2=0.82mm , a2= 3.052E+00 dB/m, A2=', str(3.052*0.24), 'dB')