import numpy as np
import matplotlib.pyplot as plt
import math

print('Microstrip: w=0.78mm, a=5.056E+00 dB/m, l=', str(1/5.056), 'm')
print('Stripline: w=0.37mm, a=7.020E+00 dB/m, l=', str(1/7.02), 'm')
