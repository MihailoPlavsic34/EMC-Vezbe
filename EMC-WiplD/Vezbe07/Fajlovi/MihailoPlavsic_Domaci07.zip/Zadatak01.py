# %%
import math as math

from numpy import mat
mu0=4*math.pi*10**(-7)
Hmax=3.98
print('Bmax je: ', Hmax, 'A/m.', 'Odnosno B=', str(Hmax*mu0) ,'T',)
print('Sto ne zadovoljava standard')
# %%
