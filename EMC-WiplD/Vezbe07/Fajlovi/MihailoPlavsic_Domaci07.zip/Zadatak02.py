# %%
from cmath import sqrt
from attr import define
import math as math
import numpy as np
from numpy import mat

fmax=1.799e9
y12=11.4e-3
R=50
c0=3e8
K=1/(y12*R)
mu0=4*math.pi*10**(-7)
print('K mora biti manje od',K)

a=300e-3
b=100e-3
c=30e-3

def kmnl(m,n,l):
    return abs(sqrt((m*math.pi/a)**2+(n*math.pi/b)**2+(l*math.pi/c)**2))

def fmnl(m,n,l):
    return c0*kmnl(m,n,l)/(2*math.pi*sqrt(mu0*1))

freqz=[]

mnl=[[1,0,0], [0,1,0], [0,0,1]]
for i in range(2):
    freqz[i] = fmnl(mnl[i][0], mnl[i][1], mnl[i][2])

print('Minimalna rezonantna frekvencija je: ', np.min(freqz))
# %%
