# %%

print('Maksimum je na otprilike 1.58 GHz')
print('Minimum je na otprilike 1.42 GHz')
# %%
