# %%
import math
f_max=2.7e9
c=3e8
print('Sprega je veca u slucaju pod b)')
print('Sprega je maksimalna na ucestanosit: 2.7GHz')
L=2*(40+20)*1e-3
Lambda=c/f_max
print('Odnos talasne duzine u slucaju maksimalne sprege i duzine spoljasnje konture je: ', str(Lambda/L),
 'sto je uporedivo obimom zatvorene zicane kruzne antene')
# %%
